using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*-------------------------------------------------------
 * Owner 		- IMAtendra
 * Project 		- Character Selector
 * Filename 	- ShowSelectedChar
 * Note 		- This is 'No Copyright Code' cause I'm Owner of this Code.
 *-------------------------------------------------------*/

public class ShowSelectedChar : MonoBehaviour
{
	public GameObject[] charPrefabs;
	private GameObject prefab, clone;

	// To Load All Characters in GameObject Array
	void Awake() => charPrefabs = Resources.LoadAll<GameObject>(path: "Characters");

	void Start()
	{
		// To Get number of your Characters
		int index = PlayerPrefs.GetInt("SelectedCharacters");
		// Load Index Character Number in prefab
		prefab = charPrefabs[index];
		// Now we create clone of your Selected Character
		clone = Instantiate(prefab, transform.position, Quaternion.identity);
	}

	void OnGUI()
	{
		// Create String for Label
		string labelChar = prefab.name;
		// Now we create a Label to Show Character Name
		GUI.Label(new Rect(Screen.width/2 - 30, 100, 100, 100), labelChar);
	}
}
